package com.test.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.model.Tasks;
import com.test.repository.TaskRepository;
import com.test.service.TaskService;

@Service
public class TaskServiceImpl implements TaskService{
	
	@Autowired
	TaskRepository taskRepository; 

	@Override
	public Tasks createTask(Tasks task) {
		return taskRepository.save(task);
	}

	@Override
	public List<Tasks> displayAllTasks() {
		return taskRepository.findAll();
	}

	@Override
	public void deleteById(Long id) {
		taskRepository.deleteById(id);
		
	}

}
