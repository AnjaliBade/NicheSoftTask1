package com.test.service;

import java.util.List;

import org.springframework.stereotype.Component;

import com.test.model.Tasks;

@Component
public interface TaskService {
	
	public Tasks createTask(Tasks task);
	
	public List<Tasks> displayAllTasks();
	
	public void deleteById(Long id);


}
