package com.test.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.test.model.Tasks;

public interface TaskRepository extends JpaRepository<Tasks, Long>{

}
