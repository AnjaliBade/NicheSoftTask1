package com.test.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.model.Tasks;
import com.test.repository.TaskRepository;
import com.test.service.TaskService;

@RestController
@RequestMapping("/task")
public class TaskController {
	
	@Autowired
	TaskRepository taskRepository;

	@Autowired
	TaskService taskService;
	
	
	@PostMapping("/create")
	public Tasks createTask(@RequestBody Tasks task) {
		return taskService.createTask(task);
	}
	
	@GetMapping("/displayAll")
	public List<Tasks> displayAllTasks(){
		return taskService.displayAllTasks();
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteById(@PathVariable Long id) {
		taskService.deleteById(id);
	}
	
}
